package TicTac;

import javax.swing.SwingUtilities;

public class TicTacToe {

	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				new TicTacToeGUI();
				
			}
			
		});
		
		
    }

}